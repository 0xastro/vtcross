/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * LICENSE INFORMATION GOES HERE
 */

/* This file is included in every source file of the VTCROSS system.  It
 * declares global flags and includes.
 */

#ifndef COMMON_H
#define COMMON_H

#ifdef HAVE_CONFIG_H
    #include "config.h"
#endif

#endif
