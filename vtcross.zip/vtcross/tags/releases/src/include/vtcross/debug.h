/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * LICENSE INFORMATION GOES HERE
 */

/* DESCRIPTION OF FILE.
 */

#ifndef DEBUG_H
#define DEBUG_H

#include <cstdio>

extern bool VTCROSS_DEBUG;

#define DEBUG(...) \
    if(VTCROSS_DEBUG) {\
        fprintf(stderr, __VA_ARGS__);\
    }

#define LOG(...) fprintf(stdout, __VA_ARGS__)

#endif
