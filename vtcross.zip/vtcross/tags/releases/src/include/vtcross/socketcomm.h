/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * TODO LICENSE INFORMATION GOES HERE
 */

/* TODO DESCRIPTION OF FILE.
 */

#ifndef SOCKET_COMM_H
#define SOCKET_COMM_H

#include <stdint.h>

#include "containers.h"


/* TODO
 */
void ReadMessage(int32_t socketFD, char *msgBuffer);

/* TODO
 */
int32_t SendMessage(int32_t socketFD, const char *message) ;

/* TODO
 */
int32_t GetParameter(int32_t socketFD, struct Parameter pList[], \
        struct Radio_Info *radio_info);

/* TODO
 */
int32_t GetRequest(int32_t socketFD, struct Parameter pList[], \
        struct Radio_Info *radio_info);

/* This is the original function that does what the above function is supposed
 * to do.
 */
int32_t ClientSocket(const char  *serverName, const char *portNumber);

/* TODO
 */
int32_t  AcceptTCPConnection(int32_t servSock);

/* TODO
 */
int32_t CreateTCPServerSocket(uint16_t port);

/* TODO
 */
int32_t InitializeTCPServerPort(int32_t servSock);

#endif
