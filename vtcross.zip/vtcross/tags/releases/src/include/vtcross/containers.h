/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * LICENSE INFORMATION GOES HERE
 */

/* This header contains commonly used data container structs in VT-CROSS
 * systems.
 */

#ifndef CONTAINERS_H
#define CONTAINERS_H


#include <netdb.h>
#include <stdint.h>
#include <string>


/* TODO
 *
 */
struct Radio_Info {
    uint32_t numUtilities;
    uint32_t numParameters;
    uint32_t numObservables;
    uint32_t policy_engine;
    uint32_t policy_socket;
    uint32_t ce_socket;
};


/* TODO
 *
 */
struct Utility {
    std::string name;
    std::string units;
    std::string goal;
    float target;
    float value;
};


/* TODO
 *
 */
struct Affect {
    Utility *u;
    std::string relation;
};


/* TODO
 *
 */
struct Parameter{
    std::string name;
    std::string units;
    float min;
    uint32_t numAffects;
    Affect affection_list[10];
    float max;
    float step;
    float value;
};


/* TODO
 *
 */
struct Observable {
    std::string name;
    Affect affection_list[10];
    uint32_t numAffects;
    float value;
};


/* TODO
 *
 */
struct Service {
    std::string name;
    int32_t socketFD;
    int32_t componentID;
    uint16_t num_conds;
    //bool cond_flag;
    std::string parameter;
    std::string input[10];
    std::string output[10];
}; 


/* TODO
 *
 */
struct Mission {
    std::string name;
    uint32_t missionID;
    uint32_t numServices;
    Service *services;
    std::string input[10];
    std::string output[10];
};

/* Registration data for Cognitive Engines for use in communication 
 */
struct CE_Reg {
    int32_t ID_num;
    //sockaddr_in *sock_ptr;
    //socklen_t sock_len;
    int32_t FD;
};

#endif
