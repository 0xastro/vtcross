/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * LICENSE INFORMATION GOES HERE
 */

/* DESCRIPTION OF FILE.
 */

#ifndef ERROR_H
#define ERROR_H

#include <cstdio>

#define ERROR(exit_code, ...) { \
    fprintf(stderr, __VA_ARGS__); \
    exit(exit_code); }

#define WARNING(...) fprintf(stderr, __VA_ARGS__)

#endif
