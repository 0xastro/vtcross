#include <cstdlib>
#include <cstring>
#include <stdint.h>
#include <string>
#include <stdlib.h> 

#include <arpa/inet.h>
#include <iostream>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "sqlite3.h"

//#include "tinyxml.h"
//#include "tinyxml.cpp"
//#include "tinystr.h"

#include "vtcross/common.h"
#include "vtcross/components.h"
#include "vtcross/containers.h"
#include "vtcross/debug.h"
#include "vtcross/error.h"
#include "vtcross/socketcomm.h"



/*#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
//#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>
#include <sqlite3ext.h>*/

//#include "common.h"

//using namespace std;


int main(int argc, char *argv[])
{  

    if(argc < 5)
       ERROR(1, "Usage: %s config hostname shell_port client_port\n", argv[0]);
 
    ServiceManagementLayer SML(argv[1], argv[2], argv[3], atoi(argv[4]));
    SML.StartSMLServer();     
}
