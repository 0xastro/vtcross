/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/*! This header exports the declaration for the Service Management Layer
 * component.
 */

#ifndef SML_H
#define SML_H


#include "components.h"


/*! \brief Service Management Layer (SML) class declaration.  
 *
 * The functions listed here are required by the CROSS API for 
 * service-oriented CROSS radio architectures.  Note that most public functions
 * are documented in the parent class, Component.
 */
class ServiceManagementLayer : public Component
{
    public:
        /*! \brief Default SML Constructor. */
        ServiceManagementLayer();

        /*! \brief Default SML Destructor. */
        ~ServiceManagementLayer();

        /*! \brief Preferred SML Constructor.
         *
         * Overloaded constructor that creates an SML and connects it to the
         * shell with the passed hostname and port.
         */
        ServiceManagementLayer(const char* SML_Config, const char* serverName, \
                const char* serverPort, int16_t clientPort);

        /*! \brief Connect the SML to a remote Shell control component. 
         *
         * Connect and register with the shell component at the passed hostname
         * and port.
         */
        void ConnectToShell(const char* serverName, const char* serverPort);

        void SendComponentType();
        void MessageHandler(int32_t ID);
        void Shutdown();
        void Reset();
        void RegisterComponent();
        void DeregisterComponent();

        /*! \brief Starts the SML Server and watches it for incoming messages
         *
         * TODO
         */
        void StartSMLServer();

    private: 
        /*! \brief Pass the radio configuration onto another component. 
         *
         * Receive the radio configuration settings from the shell and pass them
         * on to another component.
         */
        void TransferRadioConfiguration(int32_t ID);

        /*! \brief Pass a radio experience onto another component. 
         *
         * Receive information regarding a completed 'experience' and pass it on
         * to the appropriate cognitive engine.
         */
        void TransferExperience(int32_t ID);
        
        /*! Listen for other components registering their available services with
         * the SML. 
         */
        void ReceiveServices(int32_t ID);
        void DeregisterServices(int32_t ID);

        /*! Change the active mission of the radio to a new one and adjust radio
         * behavoir appropriately.
         */
        void SetActiveMission();

        /*! TODO
         */
        void RegisterCognitiveEngine(int32_t ID);
        void DeregisterCognitiveEngine(int32_t ID);

        /*! List all services provided to the radio by registered components.
         */
        void ListServices();

        /*! Load/Relead the XML configuration file. 
         */
        void ReloadConfiguration();
        void LoadConfiguration(const char *SML_Config, Mission* &mList);

        /*! Create and initialize the DB to hold the services
        */
        void CreateServicesDB();
        void CreateDataDB();

        /*! TODO
         */
        void PerformActiveMission();
        void TransactData(int32_t sourceID);

        /*! The socket file descriptor information for the shell which this SML
         * is connected to.
         */
        int32_t shellSocketFD;

        /*! TODO
         */
        int16_t CEPort;
        int16_t SMLport;

        uint32_t numberOfCognitiveEngines;

        int32_t cogEngSrv;
        int32_t activeMission;

        uint32_t Current_ID; 

        bool CE_Present;
        CE_Reg *CE_List;
        Mission *miss;
};

#endif
