/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/*! This header exports the declaration for the Cognitive Engine component type.
 */

#ifndef COGNITIVE_ENGINE_H
#define COGNITIVE_ENGINE_H


#include "components.h"


/*! \brief Cognitive Engine class declaration.
 *
 * This is the declaration for the default cognitive engine class.  Note that
 * most of the below functions are implemented in CognitiveEngine.cpp - however,
 * the functionality is very non-specific.
 *
 * Each of the 'Perform*' functions are left un-implemented, for the most part.
 *
 * The purpose of this class is to act as a non-abstract parent class.
 * Cognitive Engines should be built by publically inherting from this class,
 * and overloading the 'Perform*' functions - thus creating new and specific
 * cognitive engine functionality, without the need to rewrite or copy/paste the
 * rest of the code. Other functions that need to be overloaded include:
 *  1
 *  2
 *  3
 *
 * Note, however, that all functions are virtual.  Any function may be
 * overloaded by the child class, if desired.
 */
class CognitiveEngine : public Engine
{
    public:
        /*! Default constructor. */
        CognitiveEngine();

        /*! Default destructor. */
        ~CognitiveEngine();

        /*! \brief Preferred constructor.
         *
         * Overloaded constructor that creates a cognitive engine object and
         * connects it to either the shell or an SML, depening on the SML bool.
         *
         * The 'numFields' parameter sets how large the parameter, observable,
         * and utility arrays should be upon instantiation.
         */
        CognitiveEngine(const char* serverName, const char* serverPort, \
                const int32_t numFields, const bool SML);
        
        virtual void SendComponentType();
        virtual void ConnectToRemoteComponent(const char* serverName, \
                const char* serverPort, const bool SML);
        virtual void WaitForSignal();
        virtual void Shutdown();
        virtual void Reset();
        virtual void RegisterComponent();
        virtual void DeregisterComponent();

        virtual void RegisterServices();
        virtual void DeregisterServices();

        /*! \brief Receive radio XML configuration.
         * 
         * Receive the transmitted radio configuration from the radio itself
         * (the CE will not always be local to the radio). This gets passed
         * through either the Shell or the SML. */
        virtual void ReceiveRadioConfiguration();

        /*! \brief Receive an 'experience' report from the radio.
         *
         * An experience report can be used to build the transmission history
         * for a CE just starting up so that it has a moving start regarding
         * parameter optimization. */
        virtual void ReceiveExperience();

        /*! \brief Request that the CE optimize a set of parameters. 
         *
         * Find the most optimal set of transmission parameters given certain
         * observables and possibly a service if the SML component is present
         * and active. */
        virtual Parameter *GetSolution(Observable *observables, \
                Parameter *currentParameters);
        virtual Parameter *GetSolution(Observable *observables, \
                Parameter *currentParameters, std::string service);

        /*! \brief Receive feedback from the radio 
         *
         * Receive a feedback from the radio regarding the performance of a
         * certain set of parameters, possibly associated with a service.
         *
         * Feedback is a single set of performance statistics that is achieved
         * corresponding to a specific set of transmission parameters.  Feedback
         * helps a Cognitive Engine make better future decisions based upon 
         * more accurate performance statistics. 
         */
        virtual void ReceiveFeedback(Observable *observables,Parameter *parameters);
        virtual void ReceiveFeedback(Observable *observables, Parameter *parameters, \
                std::string service);


        /*! \brief Initialize the CE and prepare it for operation. 
         *
         * BuildCognitiveEngine performs the CE implementation specific work
         * that defines the internals of a CE.  For example, a CBR CE engine
         * would build the case-base reasoner or create the database, a neural
         * network based CE may perform the initial training, a GA based CE
         * may build the chromosome structure.
         */
        virtual void BuildCognitiveEngine();

        /*! \brief Each of these functions responds to a specific command.
         *
         * These functions are left principally un-implemented. It is the duty
         * of child classes to implement these functions, as they define the
         * cognitive engine's functionality.
         */
        virtual void PerformUpdatePerformance();
        virtual void PerformRequestOptimizationService();
        virtual void PerformRequestOptimization();
        virtual void PerformQueryComponentType();
        virtual void PerformConnectSML();
        virtual void PerformDisconnectSML();
        virtual void PerformResetEngineCognitive();
        virtual void PerformShutdownEngineCognitive();
 
        /*! \brief Keept track of what this CE is connected to. 
         *
         * The SML_present bool reflects whether or not the remote component
         * this object is connected to is an SML.  If it isn't, then it must be
         * a shell.  The socketFD stores the socket file descriptor for this
         * connection.
         */
        bool SML_present;
        int32_t commandSocketFD;
       
        // TODO Need a description for these fields.  Are these radio utilites,
        // parameters, and observables global to the whole system?
        Utility *uList;
        Parameter *pList;
        Observable *oList;
        struct Radio_Info *radioInfo;
};

#endif
