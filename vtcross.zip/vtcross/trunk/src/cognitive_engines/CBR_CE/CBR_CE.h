/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/*! This file provides a default implementation for a case-based-reasoning based
 * cognitive engine.
 */

#ifndef CBR_CE_H
#define CBR_CE_H

#include <cstdlib>
#include <cstring>
#include <stdint.h>
#include <cmath>
#include <string>

#include "vtcross/cbr.h"
#include "vtcross/cognitive_engine.h"
#include "vtcross/common.h"
#include "vtcross/containers.h"
#include "vtcross/debug.h"
#include "vtcross/error.h"
#include "vtcross/socketcomm.h"


class CBR_CE : public CognitiveEngine
{
    public:
        /*! Default constructor. */
        CBR_CE() : CognitiveEngine(){};

        /*! Default destructor. */
        ~CBR_CE(){};

        /*! \brief Preferred constructor.
         *
         * Overloaded constructor that creates a cognitive engine object and
         * connects it to either the shell or an SML, depening on the SML bool.
         *
         * The 'numFields' parameter sets how large the parameter, observable,
         * and utility arrays should be upon instantiation.
         */
        CBR_CE(const char* serverName, const char* serverPort, \
                const int32_t numFields, const bool SML);

        void RegisterServices();
        void DeregisterServices();

        /*! \brief Request that the CE optimize a set of parameters. 
         *
         * Find the most optimal set of transmission parameters given certain
         * observables and possibly a service if the SML component is present
         * and active. */
        Parameter *GetSolution(Observable *observables, \
                Parameter *currentParameters);
        Parameter *GetSolution(Observable *observables, \
                Parameter *currentParameters, std::string service);

        /*! \brief Receive feedback from the radio 
         *
         * Receive a feedback from the radio regarding the performance of a
         * certain set of parameters, possibly associated with a service.
         *
         * Feedback is a single set of performance statistics that is achieved
         * corresponding to a specific set of transmission parameters.  Feedback
         * helps a Cognitive Engine make better future decisions based upon 
         * more accurate performance statistics. 
         */
        void ReceiveFeedback(Observable *observables,Parameter *parameters);
        void ReceiveFeedback(Observable *observables, Parameter *parameters, \
                std::string service);


        /*! \brief Initialize the CE and prepare it for operation. 
         *
         * BuildCognitiveEngine performs the CE implementation specific work
         * that defines the internals of a CE.  For example, a CBR CE engine
         * would build the case-base reasoner or create the database, a neural
         * network based CE may perform the initial training, a GA based CE
         * may build the chromosome structure.
         */
        void BuildCognitiveEngine();

        /*! \brief Each of these functions responds to a specific command.
         *
         * These functions are left principally un-implemented. It is the duty
         * of child classes to implement these functions, as they define the
         * cognitive engine's functionality.
         */
        void PerformUpdatePerformance();
        void PerformRequestOptimizationService();
        void PerformRequestOptimization();
        void PerformQueryComponentType();
        void PerformConnectSML();
        void PerformDisconnectSML();
        void PerformResetEngineCognitive();
        void PerformShutdownEngineCognitive();

        CBR *myCBR;
};

#endif
