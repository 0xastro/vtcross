/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/*! This file provides a default implementation for a cognitive engine.  Note
 * that this implementation is very basic, and is meant to act as a non-abstract
 * parent class.
 */

#include <cstdlib>
#include <cstring>
#include <stdint.h>
#include <cmath>
#include <string>

#include "vtcross/cognitive_engine.h"
#include "vtcross/common.h"
#include "vtcross/containers.h"
#include "vtcross/debug.h"
#include "vtcross/error.h"
#include "vtcross/socketcomm.h"

using namespace std;


CognitiveEngine::CognitiveEngine()
{
    LOG("Creating Cognitive Engine.\n");
    SML_present = false;
    commandSocketFD = -1;
}


CognitiveEngine::~CognitiveEngine()
{
    delete [] pList;
    delete [] oList;
    delete [] uList;

    delete [] radioInfo;
}


CognitiveEngine::CognitiveEngine(const char *serverName, const char *serverPort, \
        const int32_t numFields, const bool SML)
{
    LOG("Creating Cognitive Engine.\n");

    pList = new Parameter[numFields];
    oList = new Observable[numFields];
    uList = new Utility[numFields];

    radioInfo = new Radio_Info;

    ConnectToRemoteComponent(serverName, serverPort, SML);
}


void
CognitiveEngine::SendComponentType()
{
    SendMessage(commandSocketFD, "response_engine_cognitive");
    LOG("Cognitive Engine responded to GetRemoteComponentType query.\n");
}


void
CognitiveEngine::ConnectToRemoteComponent(const char *serverName, \
        const char *serverPort, const bool SML)
{
    commandSocketFD = ClientSocket(serverName, serverPort);

    SML_present = SML;

    if(SML) {
        LOG("Cognitive Engine connected to SML at %s.\n", serverName);

        RegisterComponent();
        ReceiveRadioConfiguration();
        ReceiveExperience();
        RegisterServices();
    }
    else {
        LOG("Cognitive Engine connected to shell at %s.\n", serverName);

        RegisterComponent();
        ReceiveRadioConfiguration();
        ReceiveExperience();
    }
}


void 
CognitiveEngine::WaitForSignal()
{
    char buffer[256];

    while(true) {
        memset(buffer, 0, 256);
       
        ReadMessage(commandSocketFD, buffer);

        if(strcmp(buffer, "update_performance") == 0) {
            PerformUpdatePerformance();
        } 
        else if(strcmp(buffer, "request_optimization_service") == 0) {
            PerformRequestOptimizationService();
        }
        else if(strcmp(buffer, "request_optimization") == 0) {
            PerformRequestOptimization();
        }
        else if(strcmp(buffer, "query_component_type") == 0) {
            PerformQueryComponentType();
        }
        else if(strcmp(buffer, "connect_sml") == 0) {
            PerformConnectSML();
        }
        else if(strcmp(buffer, "disconnect_sml") == 0) {
            PerformDisconnectSML();
        }
        else if(strcmp(buffer, "reset_engine_cognitive") == 0) {
            PerformResetEngineCognitive();
        }
        else if(strcmp(buffer, "shutdown_engine_cognitive") == 0) {
            PerformShutdownEngineCognitive();
        }
    }
}


void 
CognitiveEngine::Shutdown()
{
    if(SML_present) {
        DeregisterServices();
        DeregisterComponent();
    } 
    else {
        DeregisterComponent();
    }
    // TODO Need to actually kill this process...
}


void
CognitiveEngine::Reset()
{
    LOG("Resetting Cognitive Engine.\n");

    if(SML_present) {
        DeregisterServices();
        DeregisterComponent();
    } 
    else {
        DeregisterComponent();
    }

    // TODO This function then needs to re-call "ConnectToRemoteComponent" to
    // finish the reset - otherwise, it is just a shutdown.
}


void
CognitiveEngine::RegisterComponent()
{
    char buffer[256];
    SendMessage(commandSocketFD, "register_engine_cognitive");
    LOG("Cognitive Engine:: Registration message sent to shell.\n");

    memset(buffer, 0, 256);
    ReadMessage(commandSocketFD, buffer);

    // TODO Are we reading an ACK here? If so, why aren't we doing anything with
    // it?
}

void 
CognitiveEngine::DeregisterComponent()
{
    SendMessage(commandSocketFD, "deregister_engine_cognitive");
    LOG("Cognitive Engine:: Deregistration message sent.\n");

    shutdown(commandSocketFD, 2);
    close(commandSocketFD);
    commandSocketFD = -1;
    LOG("Cognitive Engine:: Shell socket closed.\n");
}


void 
CognitiveEngine::ReceiveRadioConfiguration()
{
    LOG("Cognitive Engine:: Receiving Radio Configuration.\n");
    
    char buffer[256];
 
    /* Receive Set of Utilities */
    memset(buffer, 0, 256);
    ReadMessage(commandSocketFD, buffer);
    radioInfo->numUtilities = atoi(buffer);

    for(size_t i = 0; i < radioInfo->numUtilities; i++) {
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        uList[i].name = std::string(buffer);
   
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        uList[i].units = std::string(buffer);

        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        uList[i].goal = std::string(buffer);
    
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        uList[i].target = atof(buffer);
    }

    /* Receive Set of Parameters */
    memset(buffer, 0, 256);
    ReadMessage(commandSocketFD, buffer);
    radioInfo->numParameters = atoi(buffer);
    
    for(size_t i = 0; i < radioInfo->numParameters; i++) {
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        pList[i].name = std::string(buffer);
    
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        pList[i].units = std::string(buffer);

        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        pList[i].min = atof(buffer);
    
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        pList[i].max = atof(buffer);
    
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        pList[i].step = atof(buffer);
    
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD,buffer);
        pList[i].numAffects = atoi(buffer);
    
        for(size_t j = 0; j < pList[i].numAffects; j++) {
            memset(buffer, 0, 256);
            ReadMessage(commandSocketFD,buffer);
            // TODO for + if{break} = while?
            for(size_t k = 0; k < radioInfo->numUtilities; k++) {
                if(uList[k].name == std::string(buffer)) {    
                    pList[i].affection_list[j].u = &uList[k];   
                    break;
                }
            }

            memset(buffer, 0, 256);
            ReadMessage(commandSocketFD, buffer);
            pList[i].affection_list[j].relation = std::string(buffer);   
        }
    }   

    /* Receive Set of Observables */
    memset(buffer, 0, 256);
    ReadMessage(commandSocketFD, buffer);
    radioInfo->numObservables = atoi(buffer);
    
    for(size_t i = 0; i < radioInfo->numObservables; i++) {
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        oList[i].name = std::string(buffer);
    
        memset(buffer, 0, 256);
        ReadMessage(commandSocketFD, buffer);
        oList[i].numAffects = atoi(buffer);
    
        for(size_t j = 0; j < oList[i].numAffects; j++) {
            memset(buffer, 0, 256);
            ReadMessage(commandSocketFD, buffer);
            // TODO for + if{break} = while?
            for(size_t k = 0; k < radioInfo->numUtilities; k++) {
                if(uList[k].name == std::string(buffer)){    
                    oList[i].affection_list[j].u = &uList[k];   
                    break;
                }
            }
 
            memset(buffer, 0, 256);
            ReadMessage(commandSocketFD, buffer);
            oList[i].affection_list[j].relation = std::string(buffer);   
        }
    }

    SendMessage(commandSocketFD, "receive_config_ack");
}


void 
CognitiveEngine::ReceiveExperience()
{
    LOG("Cognitive Engine:: Receiving Experience Report.\n");
    char buffer[256];
    uint32_t numberExp;
    
    /* Receive number of experience entries */
    memset(buffer, 0, 256);
    ReadMessage(commandSocketFD, buffer);
    numberExp = atoi(buffer);

    LOG("Cognitive Engine:: Waiting for %i number of entries.\n", numberExp);
 
    SendMessage(commandSocketFD, "receive_exp_ack");
}


/***************************************************************************
 *
 * Every function below this banner must be overloaded by child classes.
 *
 ***************************************************************************/


Parameter* 
CognitiveEngine::GetSolution(Observable *observables, Parameter *currentParameters)
{
    LOG("Cognitive Engine:: Generating solution.\n");

    LOG("CognitiveEngine:: GetSolution not implemented.\n");

    return NULL;
}


Parameter* 
CognitiveEngine::GetSolution(Observable *observables, \
        Parameter *currentParameters, std::string service)
{
    LOG("Cognitive Engine:: Generating solution for %s service.\n", service.c_str());

    LOG("CognitiveEngine:: GetSolution with service not implemented.\n");

    return NULL;
}


void 
CognitiveEngine::ReceiveFeedback(Observable *observables,Parameter *parameters)
{
    LOG("Cognitive Engine:: Receiving feedback.\n");

    LOG("CognitiveEngine:: ReceiveFeedback not implemented.\n");
}


void 
CognitiveEngine::ReceiveFeedback(Observable *observables, Parameter *parameters, \
    std::string service)
{
    LOG("Cognitive Engine:: Receiving feedback.\n");

    LOG("CognitiveEngine:: ReceiveFeedback not implemented.\n");
}


void
CognitiveEngine::BuildCognitiveEngine()
{
    LOG("Cognitive Engine:: BuildCognitiveEngine not implemented.\n");
}


void 
CognitiveEngine::RegisterServices()
{
    LOG("Cognitive Engine:: RegisterServices not implemented.\n");
}


void 
CognitiveEngine::DeregisterServices()
{
    LOG("Cognitive Engine:: DeregisterServices not implemented.\n");
}


void 
CognitiveEngine::PerformUpdatePerformance()
{
}


void
CognitiveEngine::PerformRequestOptimizationService()
{
}


void
CognitiveEngine::PerformRequestOptimization()
{
}


void
CognitiveEngine::PerformQueryComponentType()
{
}


void
CognitiveEngine::PerformConnectSML()
{
}


void
CognitiveEngine::PerformDisconnectSML()
{
}


void
CognitiveEngine::PerformResetEngineCognitive()
{
}


void
CognitiveEngine::PerformShutdownEngineCognitive()
{
}
 
