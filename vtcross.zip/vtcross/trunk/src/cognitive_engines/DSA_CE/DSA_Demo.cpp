/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/* TODO DESCRIPTION OF FILE.
 *
 * This file is a temporary demo of a policy engine using some of our socket
 * communication functions. This is *not* an actual implementation of our
 * defined PolicyEngine class.
 */


#include <cstdlib>
#include <cstring>
#include <stdint.h>

#include "DSA_CognitiveEngine.h"
#include "vtcross/debug.h"
#include "vtcross/error.h"


int32_t 
main(int32_t argc, char *argv[])
{
    if(argc < 3)
       ERROR(1, "Usage: %s hostname port\n", argv[0]);
    
    DSA_CE cognitiveEngine(argv[1], argv[2], 10, false);

    LOG("Waiting for signal...\n");
    while(1) {
        cognitiveEngine.WaitForSignal();
    }

    return 0;
}

