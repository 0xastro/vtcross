# Copyright 2009 Virginia Polytechnic Institute and State University  
#
# Licensed under the Apache License, Version 2.0 (the "License"); 
# you may not use this file except in compliance with the License. 
# You may obtain a copy of the License at 
# 
# http://www.apache.org/licenses/LICENSE-2.0 
#
# Unless required by applicable law or agreed to in writing, software 
# distributed under the License is distributed on an "AS IS" BASIS, 
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
# See the License for the specific language governing permissions and 
# limitations under the License. 


# Simple Python demonstration script for using
# the CROSS system.
#
# Use with demo.xml shell configuration file
#   Instructions:
# 	Start shell with demo.xml config from the examples directory
#	Start cognitive engine
#	Run this script
#	

from cross import *

p = Parameter(2)
currentParameters = Parameter(2)
o = Observable(2)

o[0].value = 150.00
o[0].name = "throughput"

o[1].name = "PER"
o[1].value = 12.00

currentParameters[0].name = "bandwidth"
currentParameters[0].value = 300.0 

currentParameters[1].name = "bandwidth"
currentParameters[1].value = 10.0 

p = GetOptimalParameters(o,2,currentParameters,2);

for i in range(2):
    print p[i].name, p[i].value


