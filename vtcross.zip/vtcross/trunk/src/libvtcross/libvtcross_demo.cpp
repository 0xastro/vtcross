/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/


#include <cstdlib>
#include <cstring>
#include <stdint.h>

#include "vtcross/debug.h"
#include "vtcross/error.h"
#include "vtcross/libvtcross.h"
#include "vtcross/socketcomm.h"

int32_t 
main(int32_t argc, char *argv[])
{
    /* Set the location to localhost for this simple demo. */
    SetCrossShellLocation("localhost", "40000");

    for(size_t i = 0; i < 10; i++) {
        Observable *o = new Observable[2];
        Parameter *currentParameters = new Parameter[2];
        Parameter *p;

        uint32_t numParameters;
        uint32_t numObservables;
        uint32_t numUtilities;

        o[0].name = "throughput";
        o[0].value = 150.00;
        o[1].name = "PER";
        o[1].value = 12.00;

        if(i == 0) {
            currentParameters[0].name = "bandwidth";
            currentParameters[0].value = 300.0;
            currentParameters[1].name = "tx_power";
            currentParameters[1].value = 10.0;
        } else {
            currentParameters[0].value = p[0].value;
            currentParameters[1].value = p[1].value;
        }

        LOG("Application:: Requesting parameter optimization.\n");

        p = GetOptimalParameters(o,2,currentParameters,2);
        numParameters = GetNumParameters();
        numObservables = GetNumObservables();
        numUtilities = GetNumUtilities();

        LOG("Application:: Received the following parameters.\n");
        
        for(size_t i = 0; i < numParameters; i++) {
            LOG("%s:: %f\n", p[i].name.c_str(), p[i].value);
        }

        /* Try them out! Do they work? */
        o[0].value = 0.5*p[0].value + .1*p[1].value;
        o[1].value = 15-p[1].value;

        UpdateParameterPerformance(p, numParameters, o, numObservables);    
        
        delete [] p; 
        delete [] o; 
    }

    return 0;
}

