/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/*! Implementation file for the VCROSS Cognitive Radio public API defined in
 * include/libvtcross.h.
 *
 * libvtcross provides the interface that radio host platforms and applications
 * use to talk to the CROSS radio system.  All external communication with the
 * CROSS radio occurs through this library.
 */

#include <cstdlib>
#include <string>

#include "vtcross/common.h"
#include "vtcross/debug.h"
#include "vtcross/libvtcross.h"

using namespace std;


/* Strings that store the remote (or local) shell location for use within the
 * ConnectToShell() function.  Note that these values must be set with the
 * SetCrossShellLocation public function within the client code. */
string shellHostname;
string shellPort;


uint32_t
ConnectToShell()
{
    return ClientSocket(shellHostname.c_str(), shellPort.c_str());
}


void
SetCrossShellLocation(string hostname, string port)
{
    shellHostname = hostname;
    shellPort = port;
}


// TODO the following three functions all do exactly the same thing.  Why not
// simply combine them?
uint32_t
GetNumObservables()
{
    char buffer[256];

    uint32_t socketfd = ConnectToShell();
    SendMessage(socketfd, "get_number_observables");
    
    memset(buffer, 0, 256);
    ReadMessage(socketfd, buffer);
    uint32_t numObservables = atoi(buffer);
    
    return numObservables; 
}

uint32_t
GetNumUtilities()
{
    char buffer[256];

    uint32_t socketfd = ConnectToShell();
    SendMessage(socketfd, "get_number_utilities");
    
    memset(buffer, 0, 256);
    ReadMessage(socketfd, buffer);
    uint32_t numUtilities = atoi(buffer);
    
    return numUtilities; 
}

uint32_t
SetActiveMission(char * activeMission)
{
    char buffer[256];
    
    uint32_t socketfd = ConnectToShell();
    SendMessage(socketfd, "set_active_mission");

    SendMessage(socketfd, activeMission);

    //memset(buffer, 0, 256);
    //ReadMessage(socketfd, buffer);

    return 1;
}

uint32_t
GetNumParameters()
{
    char buffer[256];

    uint32_t socketfd = ConnectToShell();
    SendMessage(socketfd, "get_number_parameters");
    
    memset(buffer, 0, 256);
    ReadMessage(socketfd, buffer);
    uint32_t numParameters = atoi(buffer);
    
    return numParameters; 
}
// end previous TODO

/* Given a certain set of observables, ask the radio to find the optimum radio
 * parameters and return them. 
 *
 * TODO I'm a little confused about this function... why would anyone need to
 * use this?  Shouldn't this be internal to the radio operation? 
 *
 * TODO this function is returning a pointer to allocated memory, which is fine,
 * but we need to document this and make sure the caller is deallocating the
 * memory when it is done using it.
 */
Parameter* 
GetOptimalParameters(Observable *radioObservables, uint32_t numObservables,
        Parameter *currentParameters, uint32_t numCurrentParameters)
{
    char var[50];
    char counter[55];
    char buffer[256];

    uint32_t socketFD = ConnectToShell();
    SendMessage(socketFD, "request_optimization");

    /* Get number of observables to send.  This information needs to be 
     * sent to the Cognitive Radio Shell also.   
     */

    /* Send Observables */
    sprintf(counter, "%i", numObservables);
    SendMessage(socketFD, counter);
    for(size_t i = 0; i < numObservables; i++) {
        SendMessage(socketFD, radioObservables[i].name.c_str());
        sprintf(var, "%f", radioObservables[i].value);
        SendMessage(socketFD, var);    
    }

    /* Send Parameters */
    memset(counter, 0, 55);
    sprintf(counter, "%i", numCurrentParameters);
    SendMessage(socketFD, counter);
    for(size_t i = 0; i < numCurrentParameters; i++) {
        SendMessage(socketFD,currentParameters[i].name.c_str());
        sprintf(var,"%f",currentParameters[i].value);
        SendMessage(socketFD,var);    
    }

    /* Receive Set of Parameters */
    memset(buffer, 0, 256);
    ReadMessage(socketFD, buffer);
    uint32_t numParameters = atoi(buffer);
    Parameter *pList = new Parameter[numParameters];
    
    for(ssize_t i = 0; i < numParameters; i++) {
        memset(buffer, 0, 256);
        ReadMessage(socketFD, buffer);
        pList[i].name = std::string(buffer);
        
        memset(buffer, 0, 256);
        ReadMessage(socketFD, buffer);
        pList[i].value = atof(buffer);
    }   

    close(socketFD);
    return pList;
}

bool
UpdateParameterPerformance(Parameter *p, uint32_t numParameters, Observable *o,
        uint32_t numObservables)
{
    char counter[55];
    char var[50];

    uint32_t socketFD = ConnectToShell();
    SendMessage(socketFD, "update_performance");
    
    // Send Parameters 
    memset(counter, 0, 55);
    sprintf(counter, "%i", numParameters);
    SendMessage(socketFD, counter);
    
    for(size_t i = 0; i < numParameters; i++) {
        SendMessage(socketFD, p[i].name.c_str());
        sprintf(var, "%f", p[i].value);
        SendMessage(socketFD, var);    
    }
    
    // Send Observables
    sprintf(counter, "%i", numObservables);
    SendMessage(socketFD, counter);
    for(size_t i = 0; i < numObservables; i++) {
        SendMessage(socketFD, o[i].name.c_str());
        sprintf(var, "%f", o[i].value);
        SendMessage(socketFD, var);    
    }
}

bool ActivateComponent(uint32_t id) {
    return 1;
}
bool DeactivateComponent(uint32_t id) {
    return 1;
} 
bool DisconnectComponent(uint32_t id) {
    return 1;
}


/* View components currently connected to the radio by id. 
 *
 * TODO Should there be another way to list components? If you have 10 cognitive
 * engines, how are you going to know which is which just by id?
 */
uint32_t* GetConnectedCognitiveEngines() {
}
uint32_t* GetConnectedPolicyEngines(){
}
uint32_t* GetConnectedManagementServiceLayers(){
}
uint32_t* GetConnectedComponents(){
}


/* View data from the current status of the radio. 
 *
 * This function allows client code to capture radio properties at any certain
 * instant.  Note, however, that these properties could be changing at very
 * rapid rates. There is no guarantee that the return results from these
 * functions will still be valid by the time the client code receives them.
 */
Observable* GetRadioObservables() {
}
Parameter* GetRadioParameters(){
}
Utility* GetRadioUtilities(){
}


/* Parses VTCROSS XML configuration file and uses it to configure the radio. 
 *
 * This function *must* be called when the radio first starts up, and may be
 * called at any point after that to reconfigure the radio.
 */
bool ParseRadioConfiguration(){
}


/* Lists current radio configuration options loaded from the configuration XML
 * file. 
 *
 * TODO How are we listing these?  Are we simply returning them to stdout?
 * Logging them? Returning strings?  Need to figure this out...
 */
void ListCurrentRadioConfiguration(){
}

/* Shut down the radio.
 *
 * This function will deactivate and disconnect all radio components before
 * finally shutting down the shell and stopping radio operations.
 */
bool Shutdown(){
}

