/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/*! This header exports the declaration for the Policy Engine component type.
 */

#ifndef POLICY_ENGINE_H
#define POLICY_ENGINE_H


#include "components.h"


/*! \brief Policy Engine class declaration.  
 *
 * All public functions are inherited from parent classes Engine and Component.
 * Please see those class documentation files for further information regarding
 * public functions.
 */
class PolicyEngine : public Engine
{
    public:
        /*! \brief Default Policy Engine Constructor */
        PolicyEngine();

        /*! \brief Default Policy Engine Destructor */
        ~PolicyEngine();

        /*! \brief Preferred Policy Engine Constructor. 
         *
         * Overloaded constructor that creates a policy engine object and
         * connects it to either the shell or an SML, depening on the SML bool.
         */
        PolicyEngine(const char* serverName, const char* serverPort, \
                const bool SML);

        void SendComponentType();
        void ConnectToRemoteComponent(const char* serverName, \
                const char* serverPort, const bool SML);
        void WaitForSignal();
        void Shutdown();
        void Reset();
        void RegisterComponent();
        void DeregisterComponent();

        void RegisterServices();
        void DeregisterServices();

    private:
        /*! \brief Parse and load/reload policies into the policy engine. */
        void LoadPolicies();
        void ReloadPolicies();

        /*! \brief Return a validation decision.
         *
         * Return a decision made by the policy engine regarding a certain set
         * of transmission parameters.
         */
        void SendPEDecision(struct Parameter pList[], struct Radio_Info *radio_info, \
                int32_t decision_array[]);

        /*! \brief Perform parameter validation.
         *
         * Validate a set of transmission parameters received from the radio.
         */
        void ValidateParameters();

        /*! \brief Keep track of what control component this PE is connected to.
         *
         * The SML_present bool reflects whether or not the remote component
         * this object is connected to is an SML.  If it isn't, then it must be
         * a shell.  The socketFD stores the socket file descriptor for this
         * connection.
         */
        bool SML_present;
        int32_t commandSocketFD;
};

#endif
