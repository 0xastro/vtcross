/*
 Copyright 2009 Virginia Polytechnic Institute and State University  

 Licensed under the Apache License, Version 2.0 (the "License"); 
 you may not use this file except in compliance with the License. 
 You may obtain a copy of the License at 
 
 http://www.apache.org/licenses/LICENSE-2.0 

 Unless required by applicable law or agreed to in writing, software 
 distributed under the License is distributed on an "AS IS" BASIS, 
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 See the License for the specific language governing permissions and 
 limitations under the License. 
*/

/*! This header contains the declaration and a full implementation of 
 * the CBR class - the default CROSS case-based reasoner, which can be used as a
 * backend for cognitive engines.
 */


#ifndef CBR_H
#define CBR_H

#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <stdint.h>
#include <string>

#include <sqlite3.h>

#include "vtcross/common.h"
#include "vtcross/debug.h"
#include "vtcross/error.h"


#define DATABASENAME "cross_cbr"


/*! \brief Case-Based Reasoner class declaration.
 *
 * The CBR class is designed to used as either as-is, or as a parent class.  All
 * functions are declared virtual, and internal members are 'protected' rather
 * than private. If you require functionality in a CBR not specifically provided
 * by this class, include this header in your source file, create a new class
 * that derives from CBR, and implement your desired functionality over the
 * original virtual functions as necessary.
 */
class CBR
{
    public:
        /*! \brief Constructors for the CBR class. 
         *
         * Note that the default constructor
         * must be defined inline here so that super-calls from child classes
         * don't fail (i.e. we cannot rely on the compiler-provided constructor. */
        CBR(){};
        CBR(std::string _filename, std::string _tablename, std::string _cols[], uint32_t _len);
        CBR(std::string _filename, std::string _tablename, std::string _cols[], \
                std::string _primcols[], uint32_t _len, uint32_t _primlen);

        /*! \brief Destructors for the CBR class.
         *
         * Destructor for the CBR class. Note that this destructor will be
         * called automatically by any derived classes, and so child classes
         * should not repeat the freeing actions performed in this function. */
        virtual ~CBR();

        /*! \brief Open/Create a sqlite database for the CBR.
         *
         * This function opens the CROSS database, or if it has not been
         * created yet, creates it. */
        virtual int32_t OpenDatabase();

        /*! \brief  Execute a sqlite command.
         *
         * Construct and execute a sqlite3 command and pass the return code back. */
        virtual int32_t ExecuteCommand();

        /*! \brief Search the sqlite3 database. 
         *
         * Execute a sqlite3 search command and store the results in the passed
         * retvals argument. */
        virtual int32_t ExecuteSearchCommand(float *_retvals);

        /*! \brief Print the CROSS sqlite database. */
        virtual void Print();

        /*! \brief Search the CBR database. 
         *
         * Search the CROSS database for specific fields and store the results
         * in the passed retvals argument. */
        virtual int32_t Search(std::string _names[], int32_t *_ops, float *_vals, \
                uint32_t _n, float *_retvals);
        virtual int32_t SearchSum(std::string _name, float *_retvals);
        virtual int32_t SearchRand(std::string _names[], int32_t *_ops, float *_vals, uint32_t _n, \
            float *_retvals);

        /*! \brief Update an entry in the CBR database.  */
        virtual int32_t Update(std::string _where[], std::string _set[], float *_wherevals, \
                float *_setvals, uint32_t _wherelen, uint32_t _setlen);


        /*! \brief Add a row to the CROSS sqlite3 database. */
        virtual int32_t AddRow(std::string _cols[], float *_vals, uint32_t _len);

    protected:
        std::string filename;
        std::string tablename;
        std::string command;

        sqlite3 *db; 
        uint32_t numColumns;
};

#endif
