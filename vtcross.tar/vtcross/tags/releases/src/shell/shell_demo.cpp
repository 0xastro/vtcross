/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * TODO LICENSE INFORMATION GOES HERE
 */

/* TODO DESCRIPTION OF FILE.
 */


#include <cstdlib>
#include <stdint.h>

#include "vtcross/common.h"
#include "vtcross/components.h"
#include "vtcross/error.h"


int32_t 
main(int32_t argc, char *argv[])
{
    if(argc < 3)
       ERROR(1, "Usage: ./shell_demo config_file primary_port policy_port command_port\n", argv[0]);
    
    CognitiveRadioShell cognitiveRadioShell(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));

    cognitiveRadioShell.StartShellServer();

    return 0;
}

