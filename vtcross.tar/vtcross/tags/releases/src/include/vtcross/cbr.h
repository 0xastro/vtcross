//
// Case-based reasoner
//
//
// TODO REDO THIS FILE

#ifndef CBR_H
#define CBR_H

#include "sqlite3.h"
//#define CBR_LEN_FILENAME 64

#define DATABASENAME "cactus_cbr"

typedef struct cbr_s * cbr;

// create the CBR
cbr cbr_create(char * _filename, char * _tablename, char * _cols[], unsigned int _len);

// free the CBR
void cbr_free(cbr _cbr);

// print databse/table
void cbr_print(cbr _cbr);

#define EQ 0    // equals
#define NE 1    // not equals
#define GT 2    // greater than
#define GE 3    // greater than or equal to
#define LT 4    // less than
#define LE 5    // less than or equal to
int cbr_search(cbr _cbr, char *_names[], int * _ops, float *_vals, unsigned int _n, float *_retvals);

int cbr_add_row(cbr _cbr, char *_cols[], float *_vals, unsigned int _len);

#endif
