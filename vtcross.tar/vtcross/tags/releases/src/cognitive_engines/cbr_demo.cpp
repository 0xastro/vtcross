/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * TODO LICENSE INFORMATION GOES HERE
 */

/* TODO DESCRIPTION OF FILE.
 *
 * This file is a temporary demo of a policy engine using some of our socket
 * communication functions. This is *not* an actual implementation of our
 * defined PolicyEngine class.
 */


#include <cstdlib>
#include <cstring>
#include <stdint.h>

#include "vtcross/common.h"
#include "vtcross/components.h"
#include "vtcross/containers.h"
#include "vtcross/debug.h"
#include "vtcross/error.h"
#include "vtcross/socketcomm.h"


int32_t 
main(int32_t argc, char *argv[])
{
    if(argc < 3)
       ERROR(1, "Usage: %s hostname port\n", argv[0]);
    
    CognitiveEngine cognitiveEngine(argv[1], argv[2], false);

    LOG("Waiting for signal...\n");
    while(1) {
        cognitiveEngine.WaitForSignal();
    }

    return 0;
}

