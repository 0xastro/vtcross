#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
//#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>
#include <sqlite3ext.h>

#include "vtcross/cbr.h"
#include "vtcross/common.h"

//using namespace std;

struct CE_Info {
    int numUtilities;
    int numParameters;
    int numObservables;
};

struct Utility {
    char name[50];
    char units[50];
    char goal[50];
   /* string name;
    string units;
    string goal;*/
    float target;
    float value;
};

struct Affect {
    struct Utility u; 
    //string relation;
    char relation[50];
};      

struct Parameter {
    /*string name;
    string units;*/
    char name[50];
    char units[50];
    float min;
    int numAffects; 
    struct Affect affection_list[10];
    float max;
    float step;
    float value;
};      
        
struct Observable {
    //string name;
    char name[50];
    struct Affect affection_list[10];
    int numAffects;
    float value;
};

// error handling
void error(char *msg)
{
    perror(msg);
    exit(0);
}

void ReadMessage(int socket,char * buffer) {
    int i,n;

    n = recv(socket,buffer,256,MSG_PEEK);
    for(i=0;i<256;i++){
	    if(strcmp(&buffer[i],"\0") == 0) break;
    }
    n = recv(socket,buffer,i+1,0);
    if (n < 0) 
         error("ERROR reading from socket");
    //printf("ReadMessage:%s %d\n",buffer,n);
}


int GetUtility(int sockfd, struct Utility uList[], struct CE_Info *ce_info)
{
    char buffer[256];
    int i;

    // read unitilities
    // numUtilities
    bzero(buffer,256);
    ReadMessage(sockfd,buffer);
    ce_info->numUtilities = atoi(buffer);
    //printf("number of utilities: %d\n", ce_info->numUtilities);
        
    for (i = 0; i < ce_info->numUtilities; i++){
        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
	    //printf("Name: %s\n", buffer);
        strcpy(uList[i].name, buffer);
                 
        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
	    //printf("Units: %s\n", buffer);
        strcpy(uList[i].units, buffer);

        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
        //printf("Goal: %s\n", buffer);
        strcpy(uList[i].goal, buffer);
        
	    bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
        //printf("Target: %s\n", buffer);
        uList[i].target = atof(buffer);
    }
    return 1;
}


int GetParameter(int sockfd, struct Parameter pList[], struct CE_Info *ce_info)
{
    char buffer[256];
    int i, j;

    // numParameters
    bzero(buffer,256);
    ReadMessage(sockfd,buffer);
    ce_info->numParameters = atoi(buffer);
    //printf("number of parameters: %d\n", ce_info->numParameters);
        
    for (i = 0; i < ce_info->numParameters; i++){
        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
	    //printf("Name: %s\n", buffer);
        strcpy(pList[i].name, buffer);
                 
        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
	    //printf("Units: %s\n", buffer);
        strcpy(pList[i].units, buffer);

        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
        //printf("Min: %s\n", buffer);
        pList[i].min = atof(buffer);
        
        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
        //printf("Max: %s\n", buffer);
        pList[i].max = atof(buffer);
        
	    bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
        //printf("Step: %s\n", buffer);
        pList[i].step = atof(buffer);
    
        // numAffects
        bzero(buffer,256);
        ReadMessage(sockfd,buffer);
        pList[i].numAffects = atoi(buffer);
        //printf("number of affects: %d\n", pList[i].numAffects);
        
        for (j = 0; j < pList[i].numAffects; j++){
            bzero(buffer,256);
	        ReadMessage(sockfd,buffer);
	        //printf("Utility name: %s\n", buffer);
            strcpy(pList[i].affection_list[j].u.name, buffer);
                 
            bzero(buffer,256);
	        ReadMessage(sockfd,buffer);
	        //printf("Relation: %s\n", buffer);
            strcpy(pList[i].affection_list[j].relation, buffer);
        }
    }
    return 1;
}


int GetObservable(int sockfd, struct Observable oList[], struct CE_Info *ce_info)
{
    char buffer[256];
    int i,j;

    // numParameters
    bzero(buffer,256);
    ReadMessage(sockfd,buffer);
    ce_info->numObservables = atoi(buffer);
    //printf("number of observables: %d\n", ce_info->numObservables);
        
    for (i = 0; i < ce_info->numObservables; i++){
        bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
	    //printf("Name: %s\n", buffer);
        strcpy(oList[i].name, buffer);
                 
        // numAffects
        bzero(buffer,256);
        ReadMessage(sockfd,buffer);
        oList[i].numAffects = atoi(buffer);
        //printf("number of affects: %d\n", oList[i].numAffects);
        
        for (j = 0; j < oList[i].numAffects; j++){
            bzero(buffer,256);
	        ReadMessage(sockfd,buffer);
	        //printf("Utility name: %s\n", buffer);
            strcpy(oList[i].affection_list[j].u.name, buffer);
                 
            bzero(buffer,256);
	        ReadMessage(sockfd,buffer);
	        //printf("Relation: %s\n", buffer);
            strcpy(oList[i].affection_list[j].relation, buffer);
        }
    }
    return 1;
}


// setup client socket connection
int ClientSocket(int argc, char** argv)
{
    int sockfd;
    int portno;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    
    // setup client socket connection
    if (argc < 3) {
       fprintf(stderr,"usage: %s hostname port\n", argv[0]);
       exit(0);
    }
    // server name
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    // port no.
    portno = atoi(argv[2]);
    // socket file descriptor
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    // initiate struct socketaddr_in
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    // cast sockaddr_in to sockaddr
    if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");

    return sockfd;
}

    
int SendMessage(int socketfd, char *message) 
{
    int n;
     
    strcat(message, "\0000");
    // Write message back to client
    //n = write(socketfd,message,(strlen(message)+1));
    n = send(socketfd,message,(strlen(message)+1),0);
    if (n<0)
        error("Error sending to server\n");
    else if(n == 0)
        printf("Server closed the socket.\n");
    
    return n;
}


int GetXMLFromServer(int sockfd, struct Utility uList[], struct Parameter pList[], 
        struct Observable oList[], struct CE_Info *ce_info)
{
    // get utilities
    GetUtility(sockfd, uList, ce_info);
    
    // get parameters
    GetParameter(sockfd, pList, ce_info);

    // read obervables
    GetObservable(sockfd, oList, ce_info);

    // send ack back to server
    char buffer[256];
    strcpy(buffer, "xml received");
    SendMessage(sockfd, buffer);
    //printf("xml reception done\n");
    
    return 1;
}


int GetExperienceSize(int sockfd, int *num_rows, int *num_cols)
{
    char buffer[256];
    
    // number of rows
    bzero(buffer,256);
    ReadMessage(sockfd,buffer);
    *num_rows = atoi(buffer);
    // number of columns
    bzero(buffer,256);
    ReadMessage(sockfd,buffer);
    *num_cols = atoi(buffer);
    return 1;
}

int GetRequest(int sockfd)
{
    char buffer[256];

	bzero(buffer,256);
	ReadMessage(sockfd,buffer);

    return 1;
}

int GetExperience(int sockfd, int num_rows, int num_cols, 
        //float **past_exp)
        float past_exp[num_rows][num_cols])
{
    char buffer[256];
    int i, j;

    // read experience
    for (i = 0; i < num_rows; i++){
        for (j = 0; j < num_cols; j++){
	    bzero(buffer,256);
	    ReadMessage(sockfd,buffer);
    //    printf("experience: %s\n", buffer);
        past_exp[i][j] = atof(buffer);
        }
    }

    return 1;
}


void print_current_config(struct Utility uList[], 
        struct Parameter pList[], 
        struct Observable oList[], 
        struct CE_Info * ce_info) 
{    
    int i = 0;
    int j = 0;

    // utilities
    for(i = 0; i < ce_info->numUtilities ; i++) {
        printf("Utility: %s\n", uList[i].name);
        printf("    Units: %s\n", uList[i].units);
        printf("    Goal: %s\n", uList[i].goal);
        printf("    Target: %f\n", uList[i].target);
        /*cout << "Utility:  " << uList[i].name << endl;
        cout << "     Units:  " << uList[i].units << endl;
        cout << "     Goal:   " << uList[i].goal << endl;
        cout << "     Target: " << uList[i].target << endl;*/
    }
                       
    // parameters                        
    for(i = 0; i < ce_info->numParameters; i++) {
        printf("Paramter: %s\n", pList[i].name);
        printf("    Units: %s\n", pList[i].units);
        printf("    Min: %f\n", pList[i].min);
        printf("    Max: %f\n", pList[i].max);
        printf("    Step: %f\n", pList[i].step);
        /*cout << "Parameter:  " << pList[i].name << endl;
        cout << "       Units:   " << pList[i].units << endl;
        cout << "       Min:     " << pList[i].min << endl;
        cout << "       Max:     " << pList[i].max << endl;
        cout << "       Step:    " << pList[i].step << endl;*/
        for(j = 0; j < pList[i].numAffects; j++) {
            printf("        Affect: %s -> %s\n", pList[i].affection_list[j].u.name, pList[i].affection_list[j].relation);
            //cout << "       Affect: " << pList[i].affection_list[j].u.name << " -> " << pList[i].affection_list[j].relation << endl;
        }
    }

    // observables
    for(i = 0; i < ce_info->numObservables; i++) {
        printf("Observable: %s\n", oList[i].name);
        //cout << "Observable:  " << oList[i].name << endl;
        for(j = 0; j < oList[i].numAffects; j++) {
            printf("        Affect: %s -> %s\n", oList[i].affection_list[j].u.name, oList[i].affection_list[j].relation);
            //cout << "       Affect: " << oList[i].affection_list[j].u.name << " -> " << oList[i].affection_list[j].relation << endl;
        }
    }
}

int RunCBREngine(struct Utility uList[], struct Parameter pList[],
        struct Observable oList[], struct CE_Info *ce_info, 
        //int num_cols, int num_rows, float ** past_exp)
        int num_cols, int num_rows, float past_exp[num_rows][num_cols])
{
    
    int i, j;

    // get column names
    /*char *cols[50] = {"throughput", "spectral_efficiency", 
    "log10_ber", "mod_scheme", "tx_power", "SNR", "utility"};*/
    //char cols[num_cols][50];
   

    char **cols;
    cols = (char **)malloc(sizeof(char)*num_cols);
    j = 0;
    for (i = 0; i < ce_info->numUtilities; i++){
        cols[j] = malloc(strlen(uList[i].name)+1);
        cols[j] = uList[i].name;
    //    strcpy(cols[j], uList[i].name);
        j++;
    }
    for (i = 0; i < ce_info->numParameters; i++){
        cols[j] = malloc(strlen(pList[i].name)+1);
        cols[j] = pList[i].name;
    //    strcpy(cols[j], pList[i].name);
        j++;
    }
    for (i = 0; i < ce_info->numObservables; i++){
        cols[j] = malloc(strlen(oList[i].name)+1);
        cols[j] = oList[i].name;
    //    strcpy(cols[j], oList[i].name);
        j++;
    }
    cols[j] = malloc(strlen("utility")+1);
    cols[j] = "utility";
    
    //printf("column names:");
    //for (i = 0; i<num_cols; i++){
    //    printf(" %s",cols[i]);
    //}
    //printf("\n");

    int rc;

    // create cbr database/table
    //printf("create cbr database\n");
    char filename[] = {"ex1"}, tablename[] = {"data"};
    cbr mycbr = cbr_create(filename, tablename, cols, num_cols);
    //cbr mycbr = cbr_create("ex1", "data", cols, num_cols);

    // add row here
    float vals[num_cols];
    /*// sample table entry
    vals[0] = 1e3f;    // throughput
    vals[1] = 1;        // spectral_efficiency
    vals[2] = -3.50;    // log10_ber
    vals[3] = 1;        // mod_scheme
    vals[4] = -3.5f;    // tx_power
    vals[5] = 10.0f;   // SNR
    vals[6] = 0.762;    // utility*/
    for (i = 0; i < num_rows; i++){
        for (j = 0; j < num_cols; j++){
            vals[j] = past_exp[i][j];
        }
        rc = cbr_add_row(mycbr, cols, vals, num_cols);
    }
    
    // print
    printf("cbr table\n");
    cbr_print(mycbr);
    
    // simple search: find entry where...
    //   log10_ber < 1e-2 and SNR > 5
    //char * search_names[] = {"log10_ber", "SNR"};
    char ** search_names;
    search_names
        = (char **)malloc(sizeof(char)*(ce_info->numUtilities));
    for (i = 0; i < ce_info->numUtilities; i++){
        search_names[i] 
            = malloc(sizeof(char)*(strlen(uList[i].name)+1));
        search_names[i] = uList[i].name;
    }
    int search_ops[] = {GT, GT, LT};
    //float search_vals[] = {1e-2f, 5.f};
    float *search_vals;
    search_vals = malloc(sizeof(float)*(ce_info->numUtilities));
    for (i = 0; i < ce_info->numUtilities; i++){
        search_vals[i] = uList[i].target;
    }
    float retvals[num_cols];
    rc = cbr_search(mycbr, search_names, search_ops, 
            search_vals, ce_info->numUtilities, retvals);

    j = 0;
    for (i = 0; i < ce_info->numUtilities; i++){
        uList[i].value = retvals[j];
        j++;
    }
    for (i = 0; i < ce_info->numParameters; i++){
        pList[i].value = retvals[j];
        j++;
    }
    for (i = 0; i < ce_info->numObservables; i++){
        oList[i].value = retvals[j];
        j++;
    }

    // clean up database
    //printf("clean cbr database\n");
    cbr_free(mycbr);
    
    return 1;
}


int SendCEResults(int sockfd, struct Utility uList[], struct Parameter pList[], 
        struct Observable oList[], struct CE_Info *ce_info)
{
    // send results back to server
    char var[50];
    int i;
 
    /*// utility
    for (i = 0; i < ce_info->numUtilities; i++){
        sprintf(var, "%f", uList[i].value);
        SendMessage(sockfd, var);
    }*/
    
    // parameter
    for (i = 0; i < ce_info->numParameters; i++){
        sprintf(var, "%f", pList[i].value);
        SendMessage(sockfd, var);
    }
    
    /*// observable
    for (i = 0; i < ce_info->numObservables; i++){
        sprintf(var, "%f", oList[i].value);
        SendMessage(sockfd, var);
    }*/

    return 1;
}

int RegisterCE(int sockfd, struct Utility uList[], struct Parameter pList[], 
        struct Observable oList[], struct CE_Info *ce_info)
{
    // Send register message to cognitive radio
    SendMessage(sockfd, "register_engine_cognitive");
    return 1;
}

// main client socket
int main(int argc, char *argv[])
{
    struct Utility uList[10];
    struct Parameter pList[10];
    struct Observable oList[10];
    struct CE_Info ce_info;
    char buffer[256];

    // setup client socket connection
    int sockfd;
    sockfd = ClientSocket(argc, argv);

    RegisterCE(sockfd,uList,pList,oList,&ce_info);
    // get xml info from server
    GetXMLFromServer(sockfd, uList, pList, oList, &ce_info);
    printf("Received Radio Operation Profile from Server Successfully.\n\n");
    //print_current_config(uList, pList, oList, &ce_info); 
    
    // get experience size from server
    int num_rows, num_cols;
    GetExperienceSize(sockfd, &num_rows, &num_cols);

    // get experience
    int i, j;
    float past_exp[num_rows][num_cols];
    GetExperience(sockfd, num_rows, num_cols, past_exp);
    printf("Received Previous Radio Experience from Server Successfully.\n\n");
    // cbr operation
    //unsigned int num_cols;
    // get number of columns
    num_cols = ce_info.numUtilities + ce_info.numParameters;
    num_cols = num_cols + ce_info.numObservables;
    num_cols = num_cols + 1;    // overall utility
    //while(1) {
        
        // Wait until request is received from server to perform optimization 
        //printf("Waiting for Request for optimization from Server\n\n");
        //GetRequest(sockfd);
        //printf("Received optimization request from server\n\n");
        RunCBREngine(uList, pList, oList, &ce_info, num_cols, num_rows, past_exp);    
   
        printf("Sending optimization results to server.\n\n");
        // send results back to server
        SendCEResults(sockfd, uList, pList, oList, &ce_info);
        
    //}
    
    return 0;
}
