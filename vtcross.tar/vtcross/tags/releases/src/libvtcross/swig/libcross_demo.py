# Simple Python demonstration script for using
# the CROSS system.
#
# Use with demo.xml shell configuration file
#   Instructions:
# 	Start shell with demo.xml config from the examples directory
#	Start cognitive engine
#	Run this script
#	

from cross import *

p = Parameter(2)
currentParameters = Parameter(2)
o = Observable(2)

o[0].value = 150.00
o[0].name = "throughput"

o[1].name = "PER"
o[1].value = 12.00

currentParameters[0].name = "bandwidth"
currentParameters[0].value = 300.0 

currentParameters[1].name = "bandwidth"
currentParameters[1].value = 10.0 

p = GetOptimalParameters(o,2,currentParameters,2);

for i in range(2):
    print p[i].name, p[i].value


