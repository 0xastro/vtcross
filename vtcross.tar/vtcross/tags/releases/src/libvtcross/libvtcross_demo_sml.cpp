/* Virginia Tech Cognitive Radio Open Source Systems
 * Virginia Tech, 2009
 *
 * TODO LICENSE INFORMATION GOES HERE
 */

/* TODO DESCRIPTION OF FILE.
 *
 * This file is a temporary demo of a policy engine using some of our socket
 * communication functions. This is *not* an actual implementation of our
 * defined PolicyEngine class.
 */


#include <cstdlib>
#include <cstring>
#include <stdint.h>

#include "vtcross/debug.h"
#include "vtcross/error.h"
#include "vtcross/libvtcross.h"
#include "vtcross/socketcomm.h"

int32_t 
main(int32_t argc, char *argv[])
{
    uint32_t ret = 0;
    
    uint32_t numParameters = 2;
    uint32_t numObservables = 2;

    //for(size_t i = 0; i < 10; i++) {
        
        Observable *o = new Observable[2];
        Parameter *currentParameters = new Parameter[2];
        Parameter *p;
        
        o[0].name = "throughput";
        o[0].value = 150.00;
        o[1].name = "PER";
        o[1].value = 12.00;

        //if(i == 0) {
            currentParameters[0].name = "bandwidth";
            currentParameters[0].value = 300.0;
            currentParameters[1].name = "tx_power";
            currentParameters[1].value = 10.0;
       // } else {
       //     currentParameters[0].value = p[0].value;
       //     currentParameters[1].value = p[1].value;
       // }


	// Set the currently active SML misson
    	// Note: mission name must match a mission 
	// in the SML xml file
        SetActiveMission("0");

        // Send a request to the system for a new set of 
        //  parameters.
        p = GetOptimalParameters(o,numObservables,currentParameters,numParameters);
        
        LOG("Application:: Received the following parameters.\n");
        
        for(size_t i = 0; i < numParameters; i++) {
            LOG("%s:: %f\n", p[i].name.c_str(), p[i].value);
        }

        // Simulate the REAL observable values after the
        //  given parameters were set.

	//o[0].value = 0.5*p[0].value + .1*p[1].value;
        //o[1].value = 15-p[1].value;

        // Send the new observable values to the system with the 
        //  associated parameter set.
        //UpdateParameterPerformance(p, numParameters, o, numObservables);    
        
        delete [] p; 
        delete [] o; 
    //}

    return 0;
}

